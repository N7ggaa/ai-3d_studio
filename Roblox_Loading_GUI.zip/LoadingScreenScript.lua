-- LocalScript inside ScreenGui
game.Loaded:Wait()
wait(2) -- Optional extra loading time

-- Hide loading screen and show the button
local gui = script.Parent
gui.Frame.Visible = false
gui.StartButton.Visible = true
