-- LocalScript inside StartButton
script.Parent.MouseButton1Click:Connect(function()
	print("Game Started!")
	script.Parent.Visible = false
end)
