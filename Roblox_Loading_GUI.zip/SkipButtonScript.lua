-- LocalScript inside SkipButton
script.Parent.MouseButton1Click:Connect(function()
	local gui = script.Parent.Parent
	gui.Frame.Visible = false
	gui.StartButton.Visible = true
end)
